-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2026 at 10:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lbs_jdbc`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `Book_Code` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Author` varchar(255) DEFAULT NULL,
  `Genre` varchar(255) DEFAULT NULL,
  `Availability` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`Book_Code`, `Title`, `Author`, `Genre`, `Availability`) VALUES
(283001, 'To kill a MOCKINGBIRD', 'Harper Leeee', 'Fiction/Classic', 2),
(283002, '1984', ' George Orwell', 'Dystopian', 5),
(283003, 'The Great Gatsby', 'F. Scott Fitzgerald', 'Classic', 3),
(283004, 'Pride and Prejudice', 'Jane Austen', 'Romance', 5),
(283005, 'The Catcher in the Rye', ' J.D. Salinger', 'Coming-of-Age ', 7),
(283006, 'The Hobbit', 'J.R.R. Tolkien', 'Fantasy', 8),
(283007, 'Harry Potter and the Sorcerer’s Stone', 'J.K. Rowling', 'Fantasy', 4),
(283008, 'The Hunger Games', 'Suzanne Collins', 'Dystopian', 6),
(283009, 'The Fault in Our Stars', 'John Green', 'YA Romance', 1),
(283010, 'The Book Thief', 'Markus Zusak', 'Historical Fiction', 10),
(283011, 'The Alchemist', 'Paulo Coelho', 'Philosophical Fiction', 5),
(283012, 'The Da Vinci Code', 'Dan Brown', 'Mystery / Thriller', 3),
(283013, 'The Maze Runner', 'James Dashner', 'YA Dystopian', 7),
(283014, ' The Girl on the Train', 'Paula Hawkins', 'Psychological Thriller', 2),
(283015, 'A Game of Thrones', 'George R.R. Martin', 'Fantasy', 3),
(283016, 'The Perks of Being a Wallflower', 'Stephen Chbosky', 'YA', 2),
(283017, 'The Lightning Thief', 'Rick Riordan', 'Fantasy', 3),
(283018, 'The Outsiders', 'S.E. Hinton', 'YA Fiction', 2),
(283019, 'The Kite Runner', 'Khaled Hosseini', 'Drama', 3),
(283020, 'The Little Prince', 'Antoine de Saint-Exupéry', 'Children’s / Classic', 4);

-- --------------------------------------------------------

--
-- Table structure for table `registertable`
--

CREATE TABLE `registertable` (
  `StudentID` int(11) NOT NULL,
  `StudentName` varchar(75) DEFAULT NULL,
  `Contact_Number` varchar(15) DEFAULT NULL,
  `Course_Year` varchar(10) DEFAULT NULL,
  `Status` varchar(30) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registertable`
--

INSERT INTO `registertable` (`StudentID`, `StudentName`, `Contact_Number`, `Course_Year`, `Status`, `pass`) VALUES
(123456789, 'Laurence', '1234567', 'BSIT2E', 'STUDENT', 'qwerty'),
(202411107, 'Chan Chan', '1234567890', 'BSIT2', 'ADMIN', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `IssueNo` varchar(50) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `Book_Code` int(11) DEFAULT NULL,
  `DateIssued` date DEFAULT NULL,
  `DateReturned` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`IssueNo`, `StudentID`, `Book_Code`, `DateIssued`, `DateReturned`) VALUES
('ISSUE NO: 1768164179654-6570', 202411107, 283007, '2026-01-12', NULL),
('ISSUE NO: 1768164403088-5826', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165835388-7960', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165879938-7236', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165954250-7937', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165959494-2825', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165961060-6676', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165964422-8042', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165965945-4118', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165974518-3644', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165978493-6479', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165979920-7349', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768165988036-4737', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166093236-3659', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166131761-2701', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166134276-6722', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166135703-5048', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166217308-8301', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166375082-2930', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166383460-2217', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166385799-2664', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768166623516-5375', NULL, NULL, '2026-01-12', NULL),
('ISSUE NO: 1768167043592-4059', NULL, NULL, '2026-01-12', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`Book_Code`);

--
-- Indexes for table `registertable`
--
ALTER TABLE `registertable`
  ADD PRIMARY KEY (`StudentID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`IssueNo`),
  ADD KEY `fk_registertable` (`StudentID`),
  ADD KEY `fk_books` (`Book_Code`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_books` FOREIGN KEY (`Book_Code`) REFERENCES `books` (`Book_Code`),
  ADD CONSTRAINT `fk_registertable` FOREIGN KEY (`StudentID`) REFERENCES `registertable` (`StudentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
